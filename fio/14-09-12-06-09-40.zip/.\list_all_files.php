<?php

$dir = scandir('./');

echo '<pre>'; 
print_r($dir);
