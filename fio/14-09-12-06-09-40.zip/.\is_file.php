<?php

$isFile1 = is_file('any_fle.php');
var_dump($isFile1);

$isFile1 = is_file('any_fle123.php');
var_dump($isFile1);
