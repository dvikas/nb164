<?php

$dirName = date('Y-m-d-H-i-s');

mkdir($dirName);

rmdir($dirName);
